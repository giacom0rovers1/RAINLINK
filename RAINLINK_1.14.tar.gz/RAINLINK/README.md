RAINLINK: Retrieval algorithm for rainfall mapping from microwave links in a cellular communication network.
------

![Example](LinksAmsterdam15min201109102015StamenMapsMap.jpeg)




